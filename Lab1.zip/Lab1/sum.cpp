#include<iostream>
#include<iostring>
#include<math.h>

int sum()
{
	

	return 0;
}
