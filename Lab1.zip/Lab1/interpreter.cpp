#include<iostream>
#include<iostring>

int main()
{
	
	return 0;
}
