#include<iostream>
#include<string.h>
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>
//#include

using namespace std;

int main()
{
	pid_t pid;
	while(1)
	{
		char Cad[4];
		cout << ">>>";
		cin >> Cad;
		cout << Cad;
		if(strcmp(Cad,"sum") == 0)
		{
			pid = fork();
			cout << "Proceso creado" << pid;
			//wait();




		}
		else if(strcmp(Cad,"sub") == 0)
		{
			pid = fork();
			cout << "Proceso creado" << pid;
			//wait();

		}
		else if(strcmp(Cad,"mult") == 0)
		{
			pid = fork();
			cout << "Proceso creado" << pid;
			//wait();

		}else if(strcmp(Cad,"avg") == 0)
		{
			pid = fork();
			cout << "Proceso creado" << pid;
			//wait();

		}

	}
	
	return 0;
}
