#include<iostream>
#include<string>

int avg()
{

}
