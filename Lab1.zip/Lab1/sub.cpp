#include<iostream>
#include<string.h>
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;

int sub(int argc1, int argc2)
{
	int resultado = 0;

	if(argc1 == NULL || argc2 == NULL )
	{
		return -1;
	}
	else if(argc1 < 0 || argc2 < 0)
	{
		return -1;
	}
	else
	{		
		resultado = argc1-argc2;
		cout << resultado;
	}

	return resultado;


}

