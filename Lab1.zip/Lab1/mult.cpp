#include<iostream>
#include<string.h>
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;

int mult(int argc1, int argc2, int argc3, int argc4)
{
	int resultado = 0;

	cout << argc1 << endl;
	cout << argc2 << endl;
	cout << argc3 << endl;
	cout << argc4 << endl;

	if(argc1 == NULL || argc2 == NULL || argc3 == NULL || argc4 == NULL)
	{
		return -1;
	}
	else if(argc1 < 0 || argc2 < 0 || argc3 <0 || argc4 < 0)
	{
		return -1;
	}
	else
	{		
		resultado = argc1*argc2*argc3*argc4;
		cout << resultado;
	}

	return resultado;

}


