#include <bits/stdc++.h>
// #include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <iostream>
#include <string.h>
#include <dirent.h>
#include <stdio.h>
#include <string>

using namespace std;
//Clear Function
// #define clear() printf("\033[H\033[J")

void  parse(char *line, char **argv)
{
     while (*line != '\0') {       /* if not the end of line ....... */
          while (*line == ' ' || *line == '\t' || *line == '\n')
               *line++ = '\0';     /* replace white spaces with 0    */
          *argv++ = line;          /* save the argument position     */
          while (*line != '\0' && *line != ' ' &&
                 *line != '\t' && *line != '\n')
               line++;             /* skip the argument until ...    */
     }
     *argv = NULL;                 /* mark the end of argument list  */
}

int main(int argc, char **argv)
{
  int status, result, pip[2];
	pid_t pid_child;
  struct dirent * dp;
  string op, function = "./Commands/";

  do
  {
    bool bFoundCommand = false;
    function = "./Commands/";
    DIR* dirp = opendir(function.c_str());
    printf("Interpreter\n>>> ");
    getline(cin,op);

    if(!dirp)
    {
      printf("Error openning %s folder\n", dirp);
      break;
    }
    while (dp = readdir(dirp))
    {
      if(!strcmp(op.substr(0,op.find(' ')).c_str(),dp->d_name))
      {
        bFoundCommand = true;
        function.append(op);
        break;
      }
    }
    //
    // closedir(dirp);
    //
    if(!bFoundCommand && op.compare("Exit") != 0)
    {
      printf("Command %s was not found ...\n", op.c_str());
    }
    else
    {
      // pipe(pip);
      pid_child = fork();

      if(pid_child == 0)
      {
        char *args[100];
        parse(const_cast<char*>(function.c_str()),args);
        //close(pip[0]);
        // write(pip[1],&result,sizeof(int));
      	// close(pip[1]);
        if(execvp(function.substr(0,function.find(' ')).c_str(),args)<0)
        {
          printf("Execvp error by %s process \n", op.c_str());
          exit(1);
        }
      }
      else if(pid_child > 0)
      {
        // close(pip[1]);
        // read(pip[0],&result,sizeof(int));
        // close(pip[0]);
        //printf("%d\n", result);
        waitpid(pid_child, &status, 0);
        //printf("%d\n",(char)WEXITSTATUS(status));
        if(WEXITSTATUS(status) != 136)
        {
          printf("Result: %d\n", (char)WEXITSTATUS(status));
          //printf("%d\n", result);
        }
        else
          printf("ERROR\n");
      }
      else
        fprintf(stderr, "Fork failed \n");
      //printf("%d",(int)WEXITSTATUS(status));
    }
  } while(op.compare("Exit") != 0);
  printf("Closing Interpreter...\n");
  return 1;
}
