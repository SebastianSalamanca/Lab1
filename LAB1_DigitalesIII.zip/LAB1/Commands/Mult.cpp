#include <sys/wait.h>
#include <stdio.h>
#include <typeinfo>
#include <cstdlib>
#include <cctype>

int main(int argc, char **argv)
{
	int result = 0;
	bool bad = false;
	if(argc != 1)
	{
		if(atoi(argv[1]) != NULL)
			result = atoi(argv[1]);
		else
			bad = true;
		for(int i = 2; i < argc; i++ )
		{
			if(atoi(argv[i]) != NULL)
			result *= atoi(argv[i]);
			else
			{
				bad = true;
				break;
			}
		}
	}
	else
	 bad = true;
	if(!bad)
		exit(result);
	else
		exit(-120);
		return 1;
}
