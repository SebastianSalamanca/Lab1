#include <sys/wait.h>
#include <stdio.h>
#include <typeinfo>
#include <cstdlib>
#include <cctype>
#include <math.h>

int main(int argc, char **argv)
{
	double result = 0;
	bool bad = false;
	if(argc != 1)
	{
		for(int i = 1; i < argc; i++ )
		{
			if(atoi(argv[i]) != NULL)
				result += atoi(argv[i]);
			else
			{
				bad = true;
				break;
			}
		}
	}
	else
	 bad = true;
	if(!bad)
		exit(round(result/(argc-1)));
	else
		exit(-120);
	return 1;
}
