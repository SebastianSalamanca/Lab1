#include <sys/wait.h>
#include <stdio.h>
#include <typeinfo>
#include <cstdlib>
#include <cctype>
#include <unistd.h>

int main(int argc, char **argv)
{
	int result, pip[2];
	bool bad = false;
	//pipe(pip);

	if(argc == 3)
	{
		if(atoi(argv[2]) != NULL && atoi(argv[1]) != NULL)
		{
			result = atoi(argv[1]);
			result -= atoi(argv[2]);
		}
		else
			bad = true;
	}
	else
	 bad = true;
 	// close(pip[0]);
	// write(pip[1],&result,sizeof(int));
	// close(pip[1]);
	//printf("%d\n", result);
	if(!bad)
		//printf("Result: %d\n", result);
		exit(result);
	else
		exit(-120);
	return 1;
}
