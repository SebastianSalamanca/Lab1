#include <sys/wait.h>
#include <stdio.h>
#include <typeinfo>
#include <cstdlib>
#include <cctype>

int main(int argc, char **argv)
{
	int result = 0;
	bool bad = false;
	if(argc != 1)
	{
		for(int i = 1; i < argc; i++ )
		{
			if(atoi(argv[i]) != NULL)
				result += atoi(argv[i]);
			else
			{
				bad = true;
				break;
			}
		}
	}
	else
	 bad = true;
	if(!bad)
		exit(result);
		//printf("%d\n", result);
	else
		exit(-120);
	return result;
}
